# brandonschlack's 60 Tsangan HHKB Layout

It is used on
  
* [AN-C](https://github.com/qmk/qmk_firmware/tree/master/keyboards/cannonkeys/an_c)
* [Instant60](https://github.com/qmk/qmk_firmware/tree/master/keyboards/cannonkeys/instant60)
* [Polaris](https://github.com/qmk/qmk_firmware/tree/master/keyboards/ai03/polaris)
* [Plain60](https://github.com/qmk/qmk_firmware/tree/master/keyboards/maartenwut/plain60)

## Features
### Mod-Taps & Layer-Taps
