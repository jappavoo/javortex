# Past Breaking Changes

This page links to all previous changelogs from the QMK Breaking Changes process.

* [2023 May 28](ChangeLog/20230528.md) - version 0.21.0
* [2023 Feb 26](ChangeLog/20230226.md) - version 0.20.0
* [2022 Nov 26](ChangeLog/20221126.md) - version 0.19.0
* [2022 Aug 27](ChangeLog/20220827.md) - version 0.18.0
* [2022 May 28](ChangeLog/20220528.md) - version 0.17.0
* [2022 Feb 26](ChangeLog/20220226.md) - version 0.16.0
* [2021 Nov 27](ChangeLog/20211127.md) - version 0.15.0
* [2021 Aug 28](ChangeLog/20210828.md) - version 0.14.0
* [2021 May 29](ChangeLog/20210529.md) - version 0.13.0
* [2021 Feb 27](ChangeLog/20210227.md) - version 0.12.0
* [2020 Nov 28](ChangeLog/20201128.md) - version 0.11.0
* [2020 Aug 29](ChangeLog/20200829.md) - version 0.10.0
* [2020 May 30](ChangeLog/20200530.md) - version 0.9.0
* [2020 Feb 29](ChangeLog/20200229.md) - version 0.8.0
* [2019 Aug 30](ChangeLog/20190830.md) - version 0.7.0
